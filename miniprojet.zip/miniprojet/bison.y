%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int yylineno;
int yylex();
void yyerror(const char *s);

/* =============================== */
/*   Table des symboles (tables)   */
/* =============================== */

#define MAX_TABLES 100
#define MAX_COLUMNS 64   /* nombre max de colonnes par table (à adapter si tu veux) */

typedef struct {
    char *name;                        /* nom de la table, ex: "Etudiant" */
    int   col_count;                   /* nombre de colonnes */
    char *col_names[MAX_COLUMNS];      /* noms des colonnes */
} TableEntry;

TableEntry tables[MAX_TABLES];
int table_count = 0;

/* ========================= */
/* colonnes temporaires pour */
/* le CREATE TABLE en cours  */
/* ========================= */
char *current_col_names[MAX_COLUMNS];
int   current_col_count = 0;

/* colonnes utilisées dans un SELECT (liste_champs) */
char *current_select_cols[MAX_COLUMNS];
int   current_select_col_count = 0;
int   last_select_used_star = 0;         /* 1 si SELECT * , 0 sinon */

/* table courante pour les conditions (WHERE) */
int current_table_idx_for_condition = -1;
char *current_table_name = NULL;

void reset_current_select_cols(void) {
    current_select_col_count = 0;
    last_select_used_star = 0;
}

void add_current_select_col(char *name) {
    if (current_select_col_count >= MAX_COLUMNS) {
        fprintf(stderr, "Erreur : trop de colonnes dans SELECT.\n");
        return;
    }
    current_select_cols[current_select_col_count++] = name;
}


/* colonnes utilisées dans un INSERT INTO t (col1, col2, ...) */
char *current_insert_cols[MAX_COLUMNS];
int   current_insert_col_count = 0;

void reset_current_insert_columns(void) {
    current_insert_col_count = 0;
}

void add_current_insert_column(char *name) {
    if (current_insert_col_count >= MAX_COLUMNS) {
        fprintf(stderr, "Erreur : trop de colonnes listées dans INSERT.\n");
        return;
    }
    current_insert_cols[current_insert_col_count++] = name;
}

/* chercher une colonne dans une table, renvoie index ou -1 */
int find_column_in_table(int table_idx, const char *colname) {
    for (int j = 0; j < tables[table_idx].col_count; j++) {
        if (strcmp(tables[table_idx].col_names[j], colname) == 0) {
            return j;
        }
    }
    return -1;
}

/* reset la liste temporaire */
void reset_current_columns(void) {
    current_col_count = 0;
}

/* ajouter une colonne dans la liste temporaire */
void add_current_column(char *name) {
    if (current_col_count >= MAX_COLUMNS) {
        fprintf(stderr, "Erreur : trop de colonnes dans CREATE TABLE\n");
        return;
    }
    current_col_names[current_col_count++] = name;  /* on garde le pointeur tel quel */
}

/* chercher une table par nom, renvoie index ou -1 */
int find_table(const char *name) {
    for (int i = 0; i < table_count; i++) {
        if (strcmp(tables[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}

/* ajouter une table, renvoie 0 si OK, -1 si déjà là ou plein */
int add_table(const char *name) {
    if (find_table(name) != -1) {
        return -1; /* existe déjà */
    }
    if (table_count >= MAX_TABLES) {
        fprintf(stderr, "Erreur : trop de tables déclarées\n");
        return -1;
    }

    tables[table_count].name = strdup(name);
    tables[table_count].col_count = current_col_count;

    /* copier les pointeurs de noms de colonnes temporaires dans la table */
    for (int i = 0; i < current_col_count; i++) {
        tables[table_count].col_names[i] = current_col_names[i];
    }

    table_count++;
    return 0;
}

/* supprimer une table (pour DROP), renvoie 0 si OK, -1 si absente */
int drop_table_entry(const char *name) {
    int idx = find_table(name);
    if (idx == -1) return -1;

    /* libérer les noms de colonnes */
    for (int j = 0; j < tables[idx].col_count; j++) {
        free(tables[idx].col_names[j]);
    }

    /* on libère le nom de la table */
    free(tables[idx].name);

    /* compacter le tableau */
    for (int i = idx; i < table_count - 1; i++) {
        tables[i] = tables[i + 1];
    }
    table_count--;
    return 0;
}

%}

/* ---------------------- */
/*      union             */
/* ---------------------- */
%union {
    int    ival;
    float  fval;
    char*  sval;
    int    bval;
}

/* ---------------------- */
/*      Tokens            */
/* ---------------------- */

%token SELECT FROM WHERE INSERT INTO VALUES CREATE TABLE_
%token UPDATE SET DELETE DROP
%token AND OR NOT

%token INT_ FLOAT_ VARCHAR BOOL_

%token TRUE_ FALSE_

%token <ival> INT_CONST
%token <fval> FLOAT_CONST
%token <sval> STRING_CONST
%token <sval> IDENTIFIER

%token GEQ LEQ NEQ EQ GT LT

%token COMMA SEMICOLON LPAREN RPAREN STAR

%type <ival> valeurs
%type <ival> liste_champs
%type <ival> modifications
%type <ival> liste_ident

%start input

%%

input:
      /* vide */
    | input requete
    ;

requete:
      create_table
    | insert_into
    | select_stmt
    | update_stmt
    | delete_stmt
    | drop_table
    ;

/* CREATE TABLE */
create_table:
    CREATE TABLE_ IDENTIFIER
    {
        /* avant de lire la liste des champs, on vide la liste temporaire */
        reset_current_columns();
    }
    LPAREN champs RPAREN SEMICOLON
    {
        if (add_table($3) == -1) {
            /* table déjà existante */
            printf("ERREUR : table '%s' existe déjà.\n", $3);
        } else {
            printf("CREATE TABLE détecté : %s\n", $3);
        }
    }
    ;
champs:
      champ
    | champ COMMA champs
    ;

champ:
    IDENTIFIER type
    {
        /* $1 est le nom du champ (IDENTIFIER -> sval) */
        add_current_column($1);
    }
    ;

type:
      INT_
    | FLOAT_
    | VARCHAR
    |  VARCHAR LPAREN INT_CONST RPAREN
    | BOOL_
    ;

/* INSERT INTO */
insert_into:
    /* forme simple : INSERT INTO t VALUES (...) */
    INSERT INTO IDENTIFIER VALUES LPAREN valeurs RPAREN SEMICOLON
    {
        int idx = find_table($3);
        if (idx == -1) {
            printf("ERREUR : table '%s' inexistante pour INSERT.\n", $3);
        } else {
            int nb_cols_table = tables[idx].col_count;
            int nb_vals       = $6;  /* valeurs a retourné le nombre */

            if (nb_vals != nb_cols_table) {
                printf("ERREUR : %d valeurs fournies, mais la table '%s' a %d colonnes.\n",
                       nb_vals, $3, nb_cols_table);
            } else {
                printf("INSERT INTO %s : %d valeurs (nombre correct)\n", $3, nb_vals);
            }
        }
    }
 /* forme avec liste de colonnes : INSERT INTO t (id, nom) VALUES (...) */
  | INSERT INTO IDENTIFIER
    {
        /* on commence une nouvelle liste de colonnes pour cet INSERT */
        reset_current_insert_columns();
    }
    LPAREN liste_ident RPAREN
    VALUES LPAREN valeurs RPAREN SEMICOLON
    {
        int idx = find_table($3);
        if (idx == -1) {
            printf("ERREUR : table '%s' inexistante pour INSERT.\n", $3);
        } else {
            int nb_cols_list = $6;  /* nombre de colonnes listées (id, nom, ...) */
            int nb_vals      = $10; /* nombre de valeurs */

            if (nb_cols_list != nb_vals) {
                printf(
                    "ERREUR : %d colonnes listées, mais %d valeurs fournies pour INSERT dans '%s'.\n",
                    nb_cols_list, nb_vals, $3
                );
            } else {
                /* vérifier que chaque colonne existe dans la table */
                int ok = 1;
                for (int i = 0; i < nb_cols_list; i++) {
                    if (find_column_in_table(idx, current_insert_cols[i]) == -1) {
                        printf(
                            "ERREUR : colonne '%s' inexistante dans la table '%s'.\n",
                            current_insert_cols[i], $3
                        );
                        ok = 0;
                    }
                }

                if (ok) {
                    printf(
                        "INSERT INTO %s : %d colonnes, %d valeurs (noms & nombre corrects)\n",
                        $3, nb_cols_list, nb_vals
                    );
                }
            }
        }
    }
    ;


valeurs:
      valeur               { $$ = 1; }
    | valeur COMMA valeurs { $$ = 1 + $3; }
    ;

valeur:
      INT_CONST
    | FLOAT_CONST
    | STRING_CONST
    | TRUE_
    | FALSE_
    ;

/* SELECT */
/* SELECT */
select_stmt:
    SELECT
    {
        /* on prépare une nouvelle liste de colonnes pour ce SELECT */
        reset_current_select_cols();
    }
    select_body
    ;
    

/* Corps du SELECT, avec ou sans WHERE */
select_body:
    /* SELECT ... FROM tab;  (sans WHERE) */
    liste_champs FROM IDENTIFIER SEMICOLON
    {
        int idx = find_table($3);  /* $3 = IDENTIFIER = nom table */
        if (idx == -1) {
            printf("ERREUR : table '%s' inexistante pour SELECT.\n", $3);
        } else {
            int ok = 1;

            /* si ce n'est pas SELECT * , on vérifie les colonnes */
            if (!last_select_used_star) {
                for (int i = 0; i < current_select_col_count; i++) {
                    if (find_column_in_table(idx, current_select_cols[i]) == -1) {
                        printf("ERREUR : colonne '%s' inexistante dans la table '%s' pour SELECT.\n",
                               current_select_cols[i], $3);
                        ok = 0;
                    }
                }
            }

            if (ok) {
                printf("SELECT simple, table=%s, nb_champs=%d (colonnes OK)\n", $3, $1);
            }
        }
    }
  |
    /* SELECT ... FROM tab WHERE ... ; */
    liste_champs FROM IDENTIFIER
    {
        /* on prépare la table pour les conditions WHERE */
        int idx = find_table($3);     /* $3 = IDENTIFIER */
        current_table_idx_for_condition = idx;
        current_table_name = $3;
    }
    WHERE condition SEMICOLON
    {
        int idx = current_table_idx_for_condition;
        if (idx == -1) {
            printf("ERREUR : table '%s' inexistante pour SELECT.\n", current_table_name);
        } else {
            int ok = 1;

            /* vérifier aussi les colonnes du SELECT si ce n'est pas * */
            if (!last_select_used_star) {
                for (int i = 0; i < current_select_col_count; i++) {
                    if (find_column_in_table(idx, current_select_cols[i]) == -1) {
                        printf("ERREUR : colonne '%s' inexistante dans la table '%s' pour SELECT.\n",
                               current_select_cols[i], current_table_name);
                        ok = 0;
                    }
                }
            }

            if (ok) {
                printf("SELECT avec WHERE, table=%s, nb_champs=%d (colonnes OK)\n",
                       current_table_name, $1);
            }
        }
    }
    ;


liste_champs:
      STAR
      {
          last_select_used_star = 1;  /* on sait que c'est SELECT * */
          $$ = 1;
      }
    | IDENTIFIER
      {
          last_select_used_star = 0;
          add_current_select_col($1); /* on mémorise le nom de colonne */
          $$ = 1;
      }
    | IDENTIFIER COMMA liste_champs
      {
          last_select_used_star = 0;
          add_current_select_col($1);
          $$ = 1 + $3;
      }
    ;


liste_ident:
      IDENTIFIER
      {
          add_current_insert_column($1);
          $$ = 1;
      }
    | IDENTIFIER COMMA liste_ident
      {
          add_current_insert_column($1);
          $$ = 1 + $3;
      }
    ;


condition:
      condition OR condition_term
    | condition_term
    ;

condition_term:
      condition_term AND condition_factor
    | condition_factor
    ;

condition_factor:
      IDENTIFIER EQ valeur
    | IDENTIFIER GT valeur
    | IDENTIFIER LT valeur
    | IDENTIFIER GEQ valeur
    | IDENTIFIER LEQ valeur
    | IDENTIFIER NEQ valeur
    | LPAREN condition RPAREN
    ;




/* UPDATE */
update_stmt:
    UPDATE IDENTIFIER
    {
        int idx = find_table($2);
        if (idx == -1) {
            printf("ERREUR : table '%s' inexistante pour UPDATE.\n", $2);
            current_table_idx_for_condition = -1;
        } else {
            /* table connue : on la garde pour vérifier SET + WHERE */
            current_table_idx_for_condition = idx;
        }
    }
    SET modifications WHERE condition SEMICOLON
    {
        if (current_table_idx_for_condition != -1) {
            printf("UPDATE table=%s : %d modifications (colonnes SET/WHERE vérifiées)\n",
                   $2, $5);
        }
    }
    ;


modifications:
      modification                   { $$ = 1; }
    | modification COMMA modifications { $$ = 1 + $3; }
    ;

modification:
    IDENTIFIER EQ valeur
    {
        if (current_table_idx_for_condition >= 0 &&
            find_column_in_table(current_table_idx_for_condition, $1) == -1) {
            printf("ERREUR : colonne '%s' inexistante dans la table pour UPDATE (SET).\n", $1);
        }
    }
    ;


/* DELETE */
delete_stmt:
    /* DELETE avec WHERE */
    DELETE FROM IDENTIFIER
    {
        int idx = find_table($3);
        if (idx == -1) {
            printf("ERREUR : table '%s' inexistante pour DELETE.\n", $3);
            current_table_idx_for_condition = -1;
        } else {
            current_table_idx_for_condition = idx;
        }
    }
    WHERE condition SEMICOLON
    {
        if (current_table_idx_for_condition != -1) {
            printf("DELETE conditionnel table=%s (colonnes WHERE vérifiées)\n", $3);
        }
    }
  |
    /* DELETE sans WHERE (on garde simple) */
    DELETE FROM IDENTIFIER SEMICOLON
    {
        if (find_table($3) == -1) {
            printf("ERREUR : table '%s' inexistante pour DELETE.\n", $3);
        } else {
            printf("DELETE total table=%s\n", $3);
        }
    }
    ;


/* DROP */
drop_table:
    DROP TABLE_ IDENTIFIER SEMICOLON
    {
        if (drop_table_entry($3) == -1) {
            printf("ERREUR : table '%s' inexistante, DROP impossible.\n", $3);
        } else {
            printf("DROP TABLE %s\n", $3);
        }
    }
    ;

%%

void yyerror(const char *s){
    fprintf(stderr, "Erreur syntaxique ligne %d : %s\n", yylineno, s);
}